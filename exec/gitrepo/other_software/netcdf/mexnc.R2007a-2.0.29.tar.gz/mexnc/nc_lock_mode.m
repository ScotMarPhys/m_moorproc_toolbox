function mode = nc_lock_mode()
% NC_LOCK_MODE:  returns integer mnemonic for NC_LOCK
%
% USAGE:  mode = nc_lock_mode;
mode = 1024;
return


