mex -v -f msvc71.bat -output mexnc -Iinclude mexgateway.c netcdf2.c netcdf3.c common.c
