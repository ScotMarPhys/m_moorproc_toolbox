% Note: the NetCDF library locations are hard-wired into
% the .bat options files called below.

mex -v -f msvc8_win64.bat -output mexnc mexgateway.c netcdf2.c netcdf3.c common.c

